#include "Header1.h"

int main()
{
    student a;
    vector<student>isvestis;
    int pazymys=1, suma=0, E, i, sk, y, z;
    string ArTesti={"y"};
    string pasirinkimas1, pasirinkimas2, eilute, x, ats, dabartine;
    vector<string> eilutes;
    vector<string> surikiuota;

    cout<<"Noredami svieziu skaiciu, spauskite <y>, noredami juos nuskaityti is failo, spauskite <n>"<<endl;
    klausimas:
    pasirinkimas1=getche();
    cout<<endl;
     if(pasirinkimas1!="y" && pasirinkimas1!="n")
    {
        cout<<"Tokio pasirinkimo nebuvo, veskite is naujo:"<<endl;
        goto klausimas;
    }
    if(pasirinkimas1=="n")
    {
        ifstream in ("Kursiokai.txt");
         while(1)
    {
        eilute.clear();
        getline(in, eilute);
        if(eilute.length()==0)
            break;
        else
        {
            eilutes.push_back(eilute);
        }
    }

while(eilutes.size()>1)
{
    if(eilutes.size()<3)
    {
    surikiuota.push_back(eilutes[1]);
    break;
    }
    else
    {
    z=1;
    eilute=eilutes[1];
   for(int f=2; f<eilutes.size(); f++)
        {
        dabartine=eilutes[f];
        if(eilute>dabartine)
        {
        eilute=dabartine;
        z=f;
        }
        }
    surikiuota.push_back(eilutes[z]);
    eilutes.erase(eilutes.begin()+z);
    }

}
    for(y=0; y<surikiuota.size(); y++)
    {
        int j=0;
        suma=0;
        pazymys=0;

        a.vardas.clear();
        a.pavarde.clear();
        a.nd.clear();
        dabartine=surikiuota[y];
        while(dabartine[j]!=' ')
        {
            a.vardas.push_back(dabartine[j]);
            j++;
        }
        j++;
        while(dabartine[j]!=' ')
             {
            a.pavarde.push_back(dabartine[j]);
            j++;
            }
        for(int k=j; k<=dabartine.length(); k++)
       {
            if(dabartine[k]==' ' || k==dabartine.length())
            {
                if(a.z.length()>0)
                {
                x=a.z;
                pazymys=atoi(x.c_str());
                a.nd.push_back(pazymys);
                suma=suma+pazymys;
                a.z.clear();
                }
                else
                k=k;
            }
            else
            {
            a.z.push_back(dabartine[k]);
            }
        }
    suma=suma-a.nd[a.nd.size()-1];
    sort(a.nd.begin(), a.nd.end());
    if(a.nd.size()-1==0)
        a.mediana=a.nd[a.nd.size()];
    else if(a.nd.size()%2==0)
    {
        a.mediana=(a.nd[a.nd.size()/2-1]+a.nd[a.nd.size()/2])*1.0/2;
    }
    else
        a.mediana=a.nd[a.nd.size()/2];

    if(a.nd.size()-1==0)
        a.balas=a.nd[a.nd.size()]*1.0*0.6;
    else
    a.balas=(a.nd[a.nd.size()-1]*1.0*0.6)+(suma/(a.nd.size()-1)*1.0*0.4);
        isvestis.push_back(a);
    }
        in.close();

    cout <<setw(15)<<left<<"Vardas " <<setw(15)<<left<<"Pavarde "<<setw(15)<<left<<"Mediana "<<setw(15)<<right<<"Galutinis balas"<< endl;
    cout.fill('-');
    cout.width(60);
    cout<<"-"<<endl;
    cout.fill(' ');
        for (student x : isvestis)
            cout<<setw(15)<<left<<x.vardas<<setw(15)<<left<<x.pavarde<<setw(15)<<setprecision(2)<<fixed<<left<<x.mediana<<setw(15)<<setprecision(2)<<fixed<<right<<x.balas<<endl;
    cout.fill('-');
    cout.width(60);
    cout<<"-"<<endl;
    }
    if(pasirinkimas1=="y")
    while(ArTesti=="y")
    {
        cout << "�veskite studento varda ir pavarde: " << endl;
        cin>>a.vardas>>a.pavarde;
            if(a.vardas[0]>=97 && a.vardas[0]<=122)
                a.vardas[0]=a.vardas[0]-32;
            if (a.pavarde[0]>=97 && a.pavarde[0]<=122)
                a.pavarde[0]=a.pavarde[0]-32;
    cout<<"Jei norite pazymius vesti patys, spauskite <y>. Noredami sugeneruotu automatiskai, spauskite <n>: "<<endl;
    klausimas1:
    pasirinkimas2=getche();
    cout<<endl;
    if(pasirinkimas2!="y" && pasirinkimas2!="n")
    {
        cout<<"Tokio pasirinkimo nebuvo, veskite is naujo:"<<endl;
        goto klausimas1;
    }
    if(pasirinkimas2=="y")
    {
        cout<<"Veskite pazymius uz namu darbus. Kuomet noresite baigti, spauskite <0>"<<endl;
        pazymys=1;
        a.nd.clear();
        suma=0;
            while(pazymys!=0)
            {
                cin>>pazymys;
                    while(cin.fail() || pazymys>10 || pazymys <0)
                    {
                    cin.clear();
                    cin.ignore(256,'\n');
                    cout<<"Veskite is naujo"<<endl;
                    cin>>pazymys;
                    }
                a.nd.push_back(pazymys);
                suma=suma+pazymys;
            }
    a.nd.erase(a.nd.end()-1);
    cout<<"Koki pazymi gavo uz egzamina? "<<endl;
    cin>>E;
    if(cin.fail() || E>10 || E<0)
    {
        cin.clear();
        cin.ignore(256,'\n');
        cout<<"Veskite is naujo"<<endl;
        cin>>E;
    }

    else
        a.nd.push_back(E);
    }
    else if(pasirinkimas2=="n")
    {
     cout<<"Kiek norite pazymiu uz namu darbus?"<<endl;
     cin>>sk;
     suma=0;
     for (i=0; i<sk; i++)
        {
            pazymys=(rand()%10)+1;
            a.nd.push_back(pazymys);
            suma=suma+pazymys;
        }
            E=(rand()%10)+1;
            a.nd.push_back(E);
    }

    sort(a.nd.begin(), a.nd.end());
    if(a.nd.size()-1==0)
        a.mediana=a.nd[a.nd.size()];
    else if(a.nd.size()%2==0)
    {
        a.mediana=(a.nd[a.nd.size()/2-1]+a.nd[a.nd.size()/2])/2;
    }
    else
        a.mediana=a.nd[a.nd.size()/2];
    if(a.nd.size()-1==0)
        a.balas=E*1.0*0.6;
    else
   a.balas=(E*1.0*0.6)+(suma/(a.nd.size()-1)*1.0*0.4);
   isvestis.push_back(a);
    cout<<"Jei norite testi, spauskite <y>. Noredami pereiti prie duomenu isvedimo spauskite <n>"<<endl;
    klausimas2:
        ArTesti=getche();
    cout<<endl;
    if(ArTesti!="y" && ArTesti!="n")
    {
        cout<<"Tokio pasirinkimo nebuvo, veskite is naujo:"<<endl;
        goto klausimas2;
    }
}
if(pasirinkimas1=="y" && ArTesti=="n")
{
  cout<<"Iveskite <p> jei norite suzinoti galutini ivertinima arba <m> jei Mediana"<<endl;
  pabaiga:
    ats=getche();
    cout<<endl;
if(ats!="p" && ats!="m")
    {
    cout<<"Tokio pasirinkimo nera, veskite is naujo "<<endl;
    goto pabaiga;
    }
    else if(ats == "p")
        {
    cout <<setw(15)<<left<<"Vardas " <<setw(15)<<left<<"Pavarde "<<setw(20)<<right<<"Galutinis balas "<< endl;
    cout.fill('-');
    cout.width(50);
    cout<<"-"<<endl;
    cout.fill(' ');
        for (student x : isvestis)
            cout<<setw(15)<<left<<x.vardas<<setw(15)<<left<<x.pavarde<<setw(20)<<setprecision(2)<<fixed<<right<<x.balas<<endl;
    cout.fill('-');
    cout.width(50);
    cout<<"-"<<endl;
        }
        else if (ats == "m")
            {
    cout <<setw(15)<<left<<"Vardas " <<setw(15)<<left<<"Pavarde "<<setw(15)<<right<<"Mediana "<< endl;
    cout.fill('-');
    cout.width(45);
    cout<<"-"<<endl;
    cout.fill(' ');
        for (student x : isvestis)
            cout<<setw(15)<<left<<x.vardas<<setw(15)<<left<<x.pavarde<<setw(15)<<setprecision(2)<<fixed<<right<<x.mediana<<endl;
    cout.fill('-');
    cout.width(45);
    cout<<"-"<<endl;
    }
}
    return 0;
}
