#include"Bibliotekos.h"



extern void Testas()
{
    chrono::steady_clock::time_point start = chrono::steady_clock::now();

    string vardas, pavarde;
    string v={" "};
    string eilute, vienas={"1"}, nulis={"0"}, txt={".txt"}, dabartine, x;
    int sk, pazymys, n=5, k=1;
    fstream file;


    cout<<"Pradedami generuoti failai. Prasome palaukti"<<endl;
   for(int i=1; i<=n; i++)
   {
    k=k*10;
    vienas.clear();
    vienas={"1"};
    for(int j=1; j<=i; j++)
        vienas=vienas+nulis;
        vienas+=txt;
    file.open(vienas,ios::out);
    if(!file)
   {
       cout<<"Error in creating file!!!";
       break;
   }
   else
   {
    ofstream out (vienas);
    for(int i=1; i<=k; i++)
    {
        eilute.clear();
        vardas={"Vardas"};
        pavarde={"Pavarde"};
        ostringstream s;
        s << i;
        string geek = s.str();
        vardas+=geek;
        pavarde+=geek;
        eilute=eilute+vardas+v;
        eilute=eilute+pavarde+v;
        sk=(rand()%10)+1;
        for (int j=1; j<=sk; j++)
        {
            pazymys=(rand()%10)+1;
            ostringstream c;
            c << pazymys;
            string geek = c.str();
            eilute=eilute+geek+v;
        }
        out <<eilute<<endl;
    }
    out.close();
    file.close();
   }
   }
   cout<<"Failai sugeneruoti. Teskite"<<endl;
   cout<<endl;

   chrono::steady_clock::time_point finish=chrono::steady_clock::now();
        cout << "Jusu programa kure failus " << chrono::duration_cast<chrono::seconds>(finish - start).count() <<" sekundes"<<endl;

};

void f()
{
    ofstream out("moksliukai.txt", ios::out);
    out<<"";
    out.close();
};

void g()
{
    ofstream aut("studentai.txt", ios::out);
    aut<<"";
    aut.close();
};

