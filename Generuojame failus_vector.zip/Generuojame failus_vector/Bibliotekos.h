#ifndef HEADER1_H_INCLUDED
#define HEADER1_H_INCLUDED

#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <fstream>
#include <conio.h>
#include <string>
#include <string.h>
#include <chrono>
#include<stdio.h>

#include <bits/stdc++.h>
#include <sstream>

using namespace std;
using namespace std::chrono;

struct student
{
    vector <int> nd;
    string vardas, pavarde, z;
    double mediana, balas;
};

void Testas();
void f();
void g();

#endif // HEADER1_H_INCLUDED
