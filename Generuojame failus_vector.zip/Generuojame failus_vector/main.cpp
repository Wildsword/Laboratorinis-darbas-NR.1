#include <iostream>
#include "Bibliotekos.h"


int main()
{
    string ats, vardas, pavarde;
    vector<student>isvestis;
    student a;
    vector<student>moksliukai;
    vector<student>studentai;
    vector<double>laikas;
    vector<string>eilutes;
    string ArTesti={"y"}, pasirinkimas1, pasirinkimas2, darbas, kartoti={"y"};
    string v={" "};
    string eilute, vienas={"1"}, nulis={"0"}, txt={".txt"}, dabartine, x;
    int pazymys=1, suma=0, E, i, sk, y, dokumentas, bandymas=0;

    klausimas:
 cout<<"Noredami svieziu skaiciu, spauskite <y>, noredami patikrinti programos sparta naudojant skirtingos apimties duomenu failus, spauskite <n>"<<endl;
    pasirinkimas1=getche();
    cout<<endl;
     if(pasirinkimas1!="y" && pasirinkimas1!="n")
    {
        cout<<"Tokio pasirinkimo nebuvo, veskite is naujo:"<<endl;
        goto klausimas;
    }
    if(pasirinkimas1=="n")
{
        Testas();
        while(kartoti=="y")
    {
        f();
        g();
        moksliukai.clear();
        studentai.clear();
        vienas.clear();
        vienas={"1"};
        eilutes.clear();
        Kartojimas:
        cout<<"Yra 5 dokumentai. Spauskite skaiciu nuo 1 iki 5, noredami pasirinkit dokumenta su duomenimis nuo 10 iki 100000"<<endl;
        cin>>dokumentas;
        if(dokumentas>5 || dokumentas<1)
        {
            cout<<"Tokio pasirinkimo nera. Bandykite dar karta"<<endl;
            goto Kartojimas;
        }

        for(i=1; i<=dokumentas; i++)
            vienas=vienas+nulis;
            vienas+=txt;

    chrono::steady_clock::time_point begin = chrono::steady_clock::now();

        ifstream file (vienas);
   while(1)
    {
        eilute.clear();
        getline(file, eilute);
        if(eilute.length()==0)
            break;
        else
        {
            eilutes.push_back(eilute);
        }
    }
    for(y=0; y<eilutes.size(); y++)
    {
        int j=0;
        suma=0;
        pazymys=0;
        a.vardas.clear();
        a.pavarde.clear();
        a.nd.clear();
        dabartine=eilutes[y];
        while(dabartine[j]!=' ')
        {
            a.vardas.push_back(dabartine[j]);
            j++;
        }
        j++;
        while(dabartine[j]!=' ')
             {
            a.pavarde.push_back(dabartine[j]);
            j++;
            }
        for(int k=j; k<=dabartine.length(); k++)
       {
            if(dabartine[k]==' ' || k==dabartine.length())
            {
                if(a.z.length()>0)
                {
                x=a.z;
                pazymys=atoi(x.c_str());
                a.nd.push_back(pazymys);
                suma=suma+pazymys;
                a.z.clear();
                }
                else
                k=k;
            }
            else
            {
            a.z.push_back(dabartine[k]);
            }
        }

    if(a.nd.size()-1==0)
        a.balas=a.nd[0]*1.0*0.6;
    else
    {
    suma=suma-a.nd[a.nd.size()-1];
    a.balas=(a.nd[a.nd.size()-1]*1.0*0.6)+(suma/(a.nd.size()-1)*1.0*0.4);
    }
    if(a.balas>=5)
        moksliukai.push_back(a);
    else
        studentai.push_back(a);
    }
    file.close();

        chrono::steady_clock::time_point end=chrono::steady_clock::now();
            cout << "Jusu programa dirbo " << chrono::duration_cast<chrono::seconds>(end - begin).count() <<" sekundes"<<endl;

    chrono::steady_clock::time_point start = chrono::steady_clock::now();

    ofstream out ("moksliukai.txt", ios::out);
    out <<setw(15)<<left<<"Vardas " <<setw(15)<<left<<"Pavarde "<<setw(15)<<right<<"Galutinis balas"<< endl;
    out.fill('-');
    out.width(45);
    out<<"-"<<endl;
    out.fill(' ');
        for (student x : moksliukai)
            out<<setw(15)<<left<<x.vardas<<setw(15)<<left<<x.pavarde<<setw(15)<<setprecision(2)<<fixed<<right<<x.balas<<endl;
    out.fill('-');
    out.width(45);
    out<<"-"<<endl;

    out.close();

    ofstream aut ("studentai.txt", ios::out);
    aut <<setw(15)<<left<<"Vardas " <<setw(15)<<left<<"Pavarde "<<setw(15)<<right<<"Galutinis balas"<< endl;
    aut.fill('-');
    aut.width(45);
    aut<<"-"<<endl;
    aut.fill(' ');
        for (student x : studentai)
            aut<<setw(15)<<left<<x.vardas<<setw(15)<<left<<x.pavarde<<setw(15)<<setprecision(2)<<fixed<<right<<x.balas<<endl;
    aut.fill('-');
    aut.width(45);
    aut<<"-"<<endl;

    aut.close();


    chrono::steady_clock::time_point finish=chrono::steady_clock::now();
    cout << "Jusu programa irasinejo i faila " << chrono::duration_cast<chrono::seconds>(finish - start).count() <<" sekundes"<<endl;


    laikas.push_back((end-begin).count());
    cout<<laikas[bandymas]/pow(10*1.0, 6*1.0)<<" laikas"<<endl;
    bandymas++;
    cout<<"Noredami testi, spauskite <y> "<<endl;
    kartoti=getche();
    cout<<endl;
    if(kartoti!="y")
    {
        cout<<"Norite baigti darba? Pasirinkite <y> arba <n>"<<endl;
            Darbas:
            darbas=getche();
            cout<<endl;
                    if(darbas!="y" && darbas!="n")
                        {
                            cout<<"Tokio pasirinkimo nebuvo, veskite is naujo:"<<endl;
                            goto Darbas;
                        }
                    if(darbas=="n")
                            goto klausimas;
                    else
                            return 0;
    }

        }

}

    if(pasirinkimas1=="y")
    while(ArTesti=="y")
    {
        cout << "Iveskite studento varda ir pavarde: " << endl;
        cin>>a.vardas>>a.pavarde;
            if(a.vardas[0]>=97 && a.vardas[0]<=122)
                a.vardas[0]=a.vardas[0]-32;
            if (a.pavarde[0]>=97 && a.pavarde[0]<=122)
                a.pavarde[0]=a.pavarde[0]-32;
    cout<<"Jei norite pazymius vesti patys, spauskite <y>. Noredami sugeneruotu automatiskai, spauskite <n>: "<<endl;
    klausimas1:
    pasirinkimas2=getche();
    cout<<endl;
    if(pasirinkimas2!="y" && pasirinkimas2!="n")
    {
        cout<<"Tokio pasirinkimo nebuvo, veskite is naujo:"<<endl;
        goto klausimas1;
    }
    if(pasirinkimas2=="y")
    {
        cout<<"Veskite pazymius uz namu darbus. Kuomet noresite baigti, spauskite <0>"<<endl;
        pazymys=1;
        a.nd.clear();
        suma=0;
            while(pazymys!=0)
            {
                cin>>pazymys;
                    while(cin.fail() || pazymys>10 || pazymys <0)
                    {
                    cin.clear();
                    cin.ignore(256,'\n');
                    cout<<"Veskite is naujo"<<endl;
                    cin>>pazymys;
                    }
                a.nd.push_back(pazymys);
                suma=suma+pazymys;
            }
    a.nd.erase(a.nd.end()-1);
    cout<<"Koki pazymi gavo uz egzamina? "<<endl;
    cin>>E;
    if(cin.fail() || E>10 || E<0)
    {
        cin.clear();
        cin.ignore(256,'\n');
        cout<<"Veskite is naujo"<<endl;
        cin>>E;
    }

    else
        a.nd.push_back(E);
    }
    else if(pasirinkimas2=="n")
    {
     cout<<"Kiek norite pazymiu uz namu darbus?"<<endl;
     cin>>sk;
     suma=0;
     for (i=0; i<sk; i++)
        {
            pazymys=(rand()%10)+1;
            a.nd.push_back(pazymys);
            suma=suma+pazymys;
        }
            E=(rand()%10)+1;
            a.nd.push_back(E);
    }

    sort(a.nd.begin(), a.nd.end());
    if(a.nd.size()-1==0)
        a.mediana=a.nd[a.nd.size()];
    else if(a.nd.size()%2==0)
    {
        a.mediana=(a.nd[a.nd.size()/2-1]+a.nd[a.nd.size()/2])/2;
    }
    else
        a.mediana=a.nd[a.nd.size()/2];
    if(a.nd.size()-1==0)
        a.balas=E*1.0*0.6;
    else
   a.balas=(E*1.0*0.6)+(suma/(a.nd.size()-1)*1.0*0.4);
   isvestis.push_back(a);
    cout<<"Jei norite testi, spauskite <y>. Noredami pereiti prie duomenu isvedimo spauskite <n>"<<endl;
    klausimas2:
        ArTesti=getche();
    cout<<endl;
    if(ArTesti!="y" && ArTesti!="n")
    {
        cout<<"Tokio pasirinkimo nebuvo, veskite is naujo:"<<endl;
        goto klausimas2;
    }
}
if(pasirinkimas1=="y" && ArTesti=="n")
{
  cout<<"Iveskite <p> jei norite suzinoti galutini ivertinima arba <m> jei Mediana"<<endl;
  pabaiga:
    ats=getche();
    cout<<endl;
if(ats!="p" && ats!="m")
    {
    cout<<"Tokio pasirinkimo nera, veskite is naujo "<<endl;
    goto pabaiga;
    }
    else if(ats == "p")
        {
    cout <<setw(15)<<left<<"Vardas " <<setw(15)<<left<<"Pavarde "<<setw(20)<<right<<"Galutinis balas "<< endl;
    cout.fill('-');
    cout.width(50);
    cout<<"-"<<endl;
    cout.fill(' ');
        for (student x : isvestis)
            cout<<setw(15)<<left<<x.vardas<<setw(15)<<left<<x.pavarde<<setw(20)<<setprecision(2)<<fixed<<right<<x.balas<<endl;
    cout.fill('-');
    cout.width(50);
    cout<<"-"<<endl;
        }
        else if (ats == "m")
            {
    cout <<setw(15)<<left<<"Vardas " <<setw(15)<<left<<"Pavarde "<<setw(15)<<right<<"Mediana "<< endl;
    cout.fill('-');
    cout.width(45);
    cout<<"-"<<endl;
    cout.fill(' ');
        for (student x : isvestis)
            cout<<setw(15)<<left<<x.vardas<<setw(15)<<left<<x.pavarde<<setw(15)<<setprecision(2)<<fixed<<right<<x.mediana<<endl;
    cout.fill('-');
    cout.width(45);
    cout<<"-"<<endl;
    }
}
    return 0;
}
